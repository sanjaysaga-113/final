# Matrix Table Calculation Guide

This document explains exactly how `matrix_table.md` was produced from the files in `evaluation/output`.

## Source Files Used

- `evaluation/output/ground_truth.json`
- `evaluation/output/evaluation_report.json`
- `evaluation/output/evaluation_table.csv`
- `evaluation/output/ablation_report.json`
- `evaluation/output/ablation_table.csv`

Practical note:
- `evaluation_table.csv` already contains the per-module confusion counts and metrics.
- `ablation_table.csv` already contains per-module, per-stage metrics.
- `ground_truth.json` and `evaluation_report.json` are the audit trail showing where TP/FP/FN/TN came from.

## What Is a Matrix Here?

`matrix_table.md` contains three matrix-style tables:

1. Confusion Matrix by Module
- Rows: module (`sqli`, `bxss`, `ssrf`, `cmdi`, `xxe`)
- Columns: `TP`, `FP`, `FN`, `TN`

2. Metric Matrix by Module
- Rows: module
- Columns: `Precision`, `Recall`, `F1`, `Specificity`, `FPR`, `FNR`, `Accuracy`

3. Ablation F1 Matrix (Module x Stage)
- Rows: module
- Columns: stage (`Regression`, `Control`, `Delta_IF`, `OOB`)
- Cell value: F1 score for that module+stage

## Label Definitions (Ground Truth vs Prediction)

For each module and target key `(module, path, parameter)`:

- Positive class: target is truly vulnerable (`vulnerable: true` in `ground_truth.json`)
- Negative class: target is truly non-vulnerable (`vulnerable: false`)
- Predicted positive: scanner produced a finding for that key
- Predicted negative: scanner did not produce a finding for that key

Counts are then:

- `TP`: predicted vulnerable and truly vulnerable
- `FP`: predicted vulnerable but truly non-vulnerable
- `FN`: predicted non-vulnerable but truly vulnerable
- `TN`: predicted non-vulnerable and truly non-vulnerable

## Metric Formulas

Given TP, FP, FN, TN:

- `Precision = TP / (TP + FP)`
- `Recall = TP / (TP + FN)`
- `F1 = 2 * Precision * Recall / (Precision + Recall)`
- `Specificity = TN / (TN + FP)`
- `FPR = FP / (FP + TN)`
- `FNR = FN / (FN + TP)`
- `Accuracy = (TP + TN) / (TP + FP + FN + TN)`

Edge-case handling:
- If a denominator is zero, the metric is treated as `0.0` in these outputs.

## How Table 1 Was Built (Confusion Matrix by Module)

From `evaluation_table.csv`, read columns:
- `module,tp,fp,fn,tn`

Each row was copied directly into the first table of `matrix_table.md`.

Example row for `xxe`:
- TP=0, FP=1, FN=2, TN=1

So the matrix row is:
- `| xxe | 0 | 1 | 2 | 1 |`

## How Table 2 Was Built (Metric Matrix by Module)

From `evaluation_table.csv`, read columns:
- `precision,recall,f1,specificity,fpr,fnr,accuracy`

Values were formatted to two decimals in `matrix_table.md`.

Example for `xxe` (from report):
- TP=0, FP=1, FN=2, TN=1
- Precision = 0/(0+1)=0.00
- Recall = 0/(0+2)=0.00
- F1 = 0.00
- Specificity = 1/(1+1)=0.50
- FPR = 1/(1+1)=0.50
- FNR = 2/(2+0)=1.00
- Accuracy = (0+1)/(0+1+2+1)=1/4=0.25

These match the row shown in `matrix_table.md`.

## How Table 3 Was Built (Ablation F1 Matrix)

From `ablation_table.csv`, use columns:
- `module,stage,f1`

The table is a pivot:
- row index = `module`
- column index = `stage`
- value = `f1`

Stage name mapping in display:
- `regression -> Regression`
- `control -> Control`
- `delta_if -> Delta_IF`
- `oob -> OOB`

Values were formatted to four decimals.

Example (`ssrf`):
- regression: 0.6667
- control: 0.0000
- delta_if: 0.0000
- oob: 0.0000

## Consistency Check Against Ground Truth Inventory

From `evaluation_report.json` inventory:
- `sqli`: 1 vulnerable + 1 non-vulnerable (2 total)
- `bxss`: 1 vulnerable + 1 non-vulnerable (2 total)
- `ssrf`: 3 vulnerable + 3 non-vulnerable (6 total)
- `cmdi`: 3 vulnerable + 3 non-vulnerable (6 total)
- `xxe`: 3 vulnerable + 3 non-vulnerable (6 total)

For each module, verify:
- `TP + FN = vulnerable_targets`
- `TN + FP = non_vulnerable_targets`

This is why, for example, `xxe` in the full report corresponds to 3 positives and 3 negatives in inventory, while the matrix in `evaluation_table.csv` reflects the scoped subset used by that specific evaluation run.

## Reproducible Build Steps

If you need to regenerate `matrix_table.md`:

1. Read `evaluation/output/evaluation_table.csv`.
2. Build Table 1 using `module,tp,fp,fn,tn`.
3. Build Table 2 using metric columns, rounded to 2 decimals.
4. Read `evaluation/output/ablation_table.csv`.
5. Pivot `(module, stage, f1)` into a module x stage matrix.
6. Format Table 3 values to 4 decimals.
7. Save as `evaluation/output/matrix_table.md`.

## Files Created

- Matrix output: `evaluation/output/matrix_table.md`
- This explanation: `evaluation/output/MATRIX_CALCULATION_EXPLAINED.md`
