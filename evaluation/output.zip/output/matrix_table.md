# Evaluation Matrix Tables

## 1) Confusion Matrix by Module

| Module | TP | FP | FN | TN |
|---|---:|---:|---:|---:|
| sqli | 1 | 0 | 0 | 1 |
| bxss | 1 | 0 | 0 | 1 |
| ssrf | 3 | 0 | 0 | 3 |
| cmdi | 3 | 0 | 0 | 3 |
| xxe | 0 | 1 | 2 | 1 |

## 2) Metric Matrix by Module

| Module | Precision | Recall | F1 | Specificity | FPR | FNR | Accuracy |
|---|---:|---:|---:|---:|---:|---:|---:|
| sqli | 1.00 | 1.00 | 1.00 | 1.00 | 0.00 | 0.00 | 1.00 |
| bxss | 1.00 | 1.00 | 1.00 | 1.00 | 0.00 | 0.00 | 1.00 |
| ssrf | 1.00 | 1.00 | 1.00 | 1.00 | 0.00 | 0.00 | 1.00 |
| cmdi | 1.00 | 1.00 | 1.00 | 1.00 | 0.00 | 0.00 | 1.00 |
| xxe | 0.00 | 0.00 | 0.00 | 0.50 | 0.50 | 1.00 | 0.25 |

## 3) Ablation F1 Matrix (Module x Stage)

| Module | Regression | Control | Delta_IF | OOB |
|---|---:|---:|---:|---:|
| sqli | 1.0000 | 1.0000 | 1.0000 | 1.0000 |
| bxss | 0.0000 | 0.0000 | 0.0000 | 0.0000 |
| ssrf | 0.6667 | 0.0000 | 0.0000 | 0.0000 |
| cmdi | 1.0000 | 1.0000 | 1.0000 | 1.0000 |
| xxe | 0.0000 | 0.0000 | 0.0000 | 0.0000 |
